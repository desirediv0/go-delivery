import About from "@/components/About";
import HeroBanner from "@/components/HeroBanner";
import Instruction from "@/components/Instruction";
import Testimonial from "@/components/Testimonial";
import Image from "next/image";

export default function Home() {
  return (
    <>
      <HeroBanner/>
      <Instruction/>
      <About/>
      <Testimonial/>
    </>
  );
}
