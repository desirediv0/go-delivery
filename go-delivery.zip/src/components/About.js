import Image from 'next/image'
import React from 'react'

export default function About() {
  return (
    <section className='py-10 md:py-16'>
        <div className='container max-w-screen-xl mx-auto'>
            <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
                <div className='py-4'>
                    <h2 className='text-2xl md:text-4xl pb-4'>About Go Delivery</h2>
                    <p>The Go Delivery platform is designed to bring you the future of urban mobility now. Imagine a world where you never have to wait for your electric vehicle to recharge. That world is now a reality.VoltUp is a meticulously built eco-system, one-stop battery swapping platform that promises a future where all 2 and 3 wheeler vehicles can run with zero downtime. VoltUp is transparent, accessible, safe, and most of all instant. A perfect solution for the smart cities of our future.
                    </p>
                </div>
                <div className='py-4 justify-self-center'>
                    <Image src={"/scooter.png"} width={400} height={400} alt='scooter'></Image>
                </div>
            </div>
        </div>
    </section>
  )
}
