import Image from 'next/image'
import Link from 'next/link'
import React from 'react'
import { FaFacebook, FaInstagram, FaLinkedin, FaYoutube } from "react-icons/fa";
import { FaSquareXTwitter } from "react-icons/fa6";



export default function Footer() {
  return (
    <>
      <div className='bg-gray-900 container mx-auto text-white px-4 py-8 md:py-16'>
        <div className='grid grid-cols-1 md:grid-cols-6 gap-6'>
          <div className='md:col-span-2'>
            <p className='text-2xl'>
              <Image src="/logo.png" width={160} height={80} alt='logo'></Image>
            </p>
            <p className='pt-3 md:pt-4 text-slate-400'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus odio perspiciatis, suscipit dolores officiis veritatis rerum impedit quisquam praesentium incidunt autem aliquam ducimus voluptas nostrum, quae non. Velit, laboriosam maxime?</p>
            
          </div>
          <div>
            <p className='font-bold text-lg pb-2'>Usefull Links</p>
            <ul>
              <li className='py-1'><Link href="/" className='text-slate-400'>Home</Link></li>
              <li className='py-1'><Link href="/" className='text-slate-400'>About Us</Link></li>
              <li className='py-1'><Link href="/" className='text-slate-400'>Contact Us</Link></li>
              <li className='py-1'><Link href="/" className='text-slate-400'>Download Now</Link></li>
            </ul>
          </div>
          <div>
            <p className='font-bold text-lg pb-2'>Policies</p>
            <ul>
              <li className='py-1'><Link href="/" className='text-slate-400'>Terms & Conditions</Link></li>
              <li className='py-1'><Link href="/" className='text-slate-400'>Privacy Policy</Link></li>
              <li className='py-1'><Link href="/" className='text-slate-400'>Refund Policy</Link></li>
            </ul>
          </div>
          <div className='md:col-span-2'>
            <p className='font-bold text-lg pb-2'>Download App</p>
            <div className='flex pt-4'>
              <Link href={"/"} className='mr-3'>
                <Image src={"/google-playstore.png"} width={160} height={80} alt='google play store'></Image>
              </Link>
              <Link href={"/"} className='ml-3'>
                <Image src={"/applestore.png"} width={160} height={80} alt='google play store'></Image>
              </Link>
            </div>
            <div className='flex mt-4 md:pt-6'>
              <FaFacebook size={24} color='#93A2B7' className='mr-3' />
              <FaInstagram size={24} color='#93A2B7' className='mr-3' />
              <FaLinkedin size={24} color='#93A2B7' className='mr-3' />
              <FaSquareXTwitter size={24} color='#93A2B7' className='mr-3' />
              <FaYoutube size={24} color='#93A2B7' className='mr-3' />
            </div>
          </div>
        </div>
      </div>
      <div className='bg-slate-950 container mx-auto text-white py-5'>
        <p className='text-center'>Copyright © 2025 All right reserved</p>
      </div>
    </>
  )
}
