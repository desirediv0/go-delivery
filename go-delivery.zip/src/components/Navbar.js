"use client"
import Image from 'next/image';
import Link from 'next/link';
import React, { useState } from 'react'
import { HiMenuAlt3, HiOutlineMail, HiOutlinePhone } from "react-icons/hi";
import { LuSmartphoneCharging } from "react-icons/lu";
import { HiX } from "react-icons/hi";
import { TiSocialFacebook, TiSocialLinkedin } from "react-icons/ti";
import { SlSocialInstagram } from "react-icons/sl";

export default function Navbar() {
    // const [sidebarOpen, setSidebarOpen] = useState(false);
    const [state, setState] = useState(false)

    // Replace javascript:void(0) path with your path
    const navigation = [
        { title: "Home", path: "/" },
        { title: "About Us", path: "/about" },
        { title: "Quality & Certification", path: "/quality-and-certification" },
        { title: "Product Catalogue", path: "/product-catalogue" },
        { title: "Contact", path: "/contact" },
    ]
    const contactMethod = [
        {
            icon: <HiOutlineMail size={20} />,
            contact: "sales@flydaerospares.com"
        },
        {
            icon:
                <HiOutlinePhone size={20} />
            ,
            contact: "+91-9999046374"
        }
    ]
    const social = [
        <TiSocialFacebook size={25} />,
        <TiSocialLinkedin size={25} />,
        <SlSocialInstagram size={20} />
    ]
    return (
        <>
            <nav className="relative items-center py-5 px-4 mx-auto max-w-screen-xl sm:px-8 md:flex md:space-x-6">
                <div className="flex justify-between">
                    <Link href="/">
                        <Image
                            src="/logo.png"
                            width={100}
                            height={50}
                            alt="Float UI logo"
                            unoptimized
                        />
                    </Link>
                    <button className="text-gray-500 outline-none md:hidden"
                        onClick={() => setState(!state)}
                    >
                        {
                            state ? <HiX size={25} /> : <HiMenuAlt3 size={25} />
                        }
                    </button>
                </div>
                <ul className={`flex-1 justify-between mt-12 md:text-sm md:font-medium md:flex md:mt-0 ${state ? 'absolute inset-x-0 px-4 border-b bg-white md:border-none md:static' : 'hidden'}`}>
                    <div className="items-center space-y-5 md:flex md:space-x-6 md:space-y-0 md:ml-12">
                        {
                            navigation.map((item, idx) => (
                                <li className="text-gray-500" key={idx}>
                                    <Link className='hover:text-sky-600 p-1' href={item.path}>{item.title}</Link>
                                </li>
                            ))
                        }
                    </div>
                    <li className="order-2 py-5 md:py-0">
                        <Link href="/contact" className="py-2 px-5 font-medium text-white text-center bg-[#093e5e] hover:bg-[#072f48] active:bg-[#072f48] duration-150 md:py-3 flex">
                        <LuSmartphoneCharging size={24} />
                            <span className='ml-2 py-1'>GET THE APP</span>
                        </Link>
                    </li>
                </ul>
            </nav>
        </>
    )
}
