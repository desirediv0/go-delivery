import React from 'react'

export default function HeroBanner() {
  return (
    <div className='bg-[url(/banner.jpg)] bg-cover bg-center bg-no-repeat'>
        <div className='container max-w-screen-xl mx-auto text-center px-4 py-32 md:py-60 text-white'>
            <h1 className='text-3xl md:text-5xl mx-auto font-semibold pb-4'>The Future is Electric – Are You Ready?</h1>
            <p className='text-2xl md:text-4xl'>Go Green India with Go Delivery</p>
        </div>
    </div>
  )
}
