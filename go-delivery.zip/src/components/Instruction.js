import Image from 'next/image'
import Link from 'next/link'
import React from 'react'
import { FaCarBattery } from "react-icons/fa";
import { MdOutlineSupportAgent } from "react-icons/md";
import { IoIosSpeedometer } from "react-icons/io";
import { FaPiggyBank } from "react-icons/fa6";





export default function Instruction() {
    return (
        <section className='bg-[#F2FFFF]'>
        <div className='container max-w-screen-xl mx-auto py-6 md:py-10'>
            <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
                <div>
                    <Image src={"/phone.png"} width={600} height={600} alt='phone'></Image>
                </div>
                <div className='py-14'>
                    <h2 className='text-2xl md:text-4xl font-semibold pb-4'>Discover Go Delivery</h2>
                    <p>Ride the HIGH PERFORMANCE powerful two-wheeler and three Wheeler cargo vehicles on easy rentals and maximize your earnings by saving fuel cost and go green with ZERO EMISSIONS.</p>
                    <div className='grid grid-cols-1 md:grid-cols-2 gap-4 py-4'>
                        <div className='text-center py-4'>
                            <FaCarBattery size={40} color='#072f48' className='mx-auto' />
                            <p>High Performance Battery</p>
                        </div>
                        <div className='text-center py-4'>
                            <MdOutlineSupportAgent size={40} color='#072f48' className='mx-auto' />
                            <p>24*7 Support</p>
                        </div>
                        <div className='text-center py-4'>
                            <IoIosSpeedometer size={40} color='#072f48' className='mx-auto' />
                            <p>100-120Km Range</p>
                        </div>
                        <div className='text-center py-4'>
                            <FaPiggyBank size={40} color='#072f48' className='mx-auto' />
                            <p>Save Money</p>
                        </div>
                    </div>
                    <div className='flex pt-4'>
                        <Link href={"/"} className='mr-3'>
                            <Image src={"/google-playstore.png"} width={160} height={80} alt='google play store'></Image>
                        </Link>
                        <Link href={"/"} className='ml-3'>
                            <Image src={"/applestore.png"} width={160} height={80} alt='google play store'></Image>
                        </Link>
                    </div>
                </div>
            </div>
        </div>
        </section>
    )
}
